outputFile = 'fixed_maze.txt'
out = open(outputFile, 'w')

def manual_replace(s, char, index):
    return s[:index] + char + s[index +1:]

with open('unfixed_maze.txt') as f:
    for index, line in enumerate(f):
        if ('|' in line):
            line = manual_replace(line, '*', 0)
            # print("Line {}: {}".format(index, line))
        if (not line.isspace()):
            out.write(line)

out.close()